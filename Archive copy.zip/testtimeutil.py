# Program that accepts an integer (0-999) as a parameter and returns the English language equivalent
# Makanaka Mangwanda
# 11 April 2024

"""
>>> import timeutil

>>> timeutil.validate('00:45 a.m')
False
>>> timeutil.validate('111:01 p.m')
False
>>> timeutil.validate('12:76 p.m')
False
>>> timeutil.validate('11:12')
False
>>> timeutil.validate(':36 a.m')
False
>>> timeutil.validate('11:17  p.m')
False

"""

import doctest
doctest.testmod(verbose=True)