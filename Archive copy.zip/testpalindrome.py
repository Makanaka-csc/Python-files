# Program that concerns devising a set of tests for a Python function that cumulatively achieve statement coverage
# Makanaka Mangwanda 
# 10 April 2024

"""
>>> import palindrome
>>> palindrome.is_palindrome('565')
True
>>> palindrome.is_palindrome('a')
True
>>> palindrome.is_palindrome('aa')
True
>>> palindrome.is_palindrome('hello')
False
>>> palindrome.is_palindrome("")
True

"""


import doctest
doctest.testmod(verbose=True)