# My very first program to display Hello world on screen
# Name : Makanaka Mangwanda
# Student number : MNGMAK013
# Date : 22 February 2024

print('Hello World')